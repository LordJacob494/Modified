Installation Put Modified.dll in plugin folder in BepInEx folder in Tabs Directorty

https://totally-accurate-battle-simulator.thunderstore.io/package/BepInEx/BepInExPack_TABS/

right above is where you can find BepInEx to download i wont go further into how to download BepInEx

because it already gives you installation for BepInEx

this is my first mod hope you like and go play around